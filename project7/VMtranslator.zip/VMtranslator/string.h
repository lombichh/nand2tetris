// returns true if the path is a directory, false otherwise
int is_directory(char *path);

// returns true if str1 ends with str2, false otherwise
int end_with(char *str1, char *str2);